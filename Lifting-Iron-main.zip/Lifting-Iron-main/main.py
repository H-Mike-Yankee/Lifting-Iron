import pandas as pd
import random
import requests
from fastapi import FastAPI, HTTPException, Request, Header
from fastapi.middleware.cors import CORSMiddleware
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import uvicorn
import nest_asyncio
import logging
from datetime import datetime, timedelta

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

headers={
    "x-forwarded-from":'https://predict.liftingiron.co.uk/'
}

# Constants for header validation
EXPECTED_HEADER = "https://api.server.liftingiron.co.uk/"

# Define the API endpoint for the nutrition and user data
NUTRITION_API_URL = 'https://api.server.liftingiron.co.uk/api/ai/nutritions'
USER_API_URL = 'https://api.server.liftingiron.co.uk/api/ai/profile'
# requests.get('https://api.server.liftingiron.co.uk/',headers=headers)

# # Allowed IP address
# ALLOWED_IP = '192.168.100.23'  # Replace with your specific IP

# CORS configuration
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace with your frontend's URL in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# # Middleware to restrict access to specific IP
# @app.middleware("http")
# async def restrict_ip_middleware(request: Request, call_next):
#     client_ip = request.client.host
#     if client_ip != ALLOWED_IP:
#         logger.warning(f"Unauthorized access attempt from {client_ip}")
#         raise HTTPException(status_code=403, detail="Access forbidden from this IP")

#     response = await call_next(request)
#     return response


# Function to fetch nutrition data
def fetch_nutrition_data():
    try:
        response = requests.get(NUTRITION_API_URL,headers=headers)
        response.raise_for_status()  # Raise an error for bad responses
        return response.json()['nutritions']
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to fetch nutrition data: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch nutrition data")


# Function to fetch user data
def fetch_user_data():
    try:
        response = requests.get(USER_API_URL,headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to fetch user data: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch user data")


# Fetch the data
try:
    nutrition_data = fetch_nutrition_data()
    user_data = fetch_user_data()
except HTTPException as e:
    logger.critical(f"Critical error: {e.detail}")
    exit(1)

# Convert to DataFrames
nutrition_df = pd.DataFrame(nutrition_data)[
    ['id', 'title', 'ingredients', 'instructions', 'duration', 'calories', 'category', 'group']]
user_df = pd.DataFrame(user_data)


# Preprocessing function for user data
def preprocess_user_data(df):
    df['dob'] = pd.to_datetime(df['dob'], format='%m-%d-%Y', errors='coerce')
    if df['dob'].isnull().any():
        raise ValueError("Invalid date format for 'dob'")

    df['Age'] = pd.to_datetime('today').year - df['dob'].dt.year

    # Convert height and weight to numerical values
    df['Height'] = df['height'].apply(lambda x: x['value'])
    df['Weight'] = df['weight'].apply(lambda x: x['value'])

    # Calculate BMI
    df['BMI'] = df['Weight'] / ((df['Height'] / 100) ** 2)

    # Select only numerical features for scaling
    numerical_features = ['Age', 'Height', 'Weight', 'BMI']
    df_numerical = df[numerical_features]

    return df_numerical


# Preprocess the user data
try:
    X = preprocess_user_data(user_df)
except ValueError as e:
    logger.error(f"Preprocessing error: {e}")
    exit(1)

# Extract target (category name) from nutrition data
nutrition_df['category_name'] = nutrition_df['category'].apply(lambda x: x['name'])
y = nutrition_df['category_name']

# Ensure X and y have the same number of samples
num_samples = min(X.shape[0], y.shape[0])
X = X[:num_samples]
y = y[:num_samples]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale the data
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Model training
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)


@app.get("/")
def welcome():
    return {"message": "Welcome to the AI API"}


@app.post("/predict/nutrition")
def predict(user_input: dict, x_forwarded_from: str = Header(None)):
    if x_forwarded_from != EXPECTED_HEADER:
        logger.warning("Unauthorized access attempt with incorrect 'x-forwarded-from' header")
        raise HTTPException(status_code=403, detail="Unauthorized access")


    logger.info("Received user input: %s", user_input)

    input_df = pd.DataFrame([user_input])

    try:
        X_new = preprocess_user_data(input_df)
    except ValueError as e:
        logger.error(f"Preprocessing error with input: {user_input} - {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))

    try:
        X_new = scaler.transform(X_new)
    except Exception as e:
        logger.error(f"Error during scaling: {e}")
        raise HTTPException(status_code=500, detail="Error during scaling")

    prediction = model.predict(X_new)

    dietary_prefs = user_input.get("dietaryPrefs", [])
    filtered_meals = [meal for meal in nutrition_data if
                      all(pref in meal['category']['name'] for pref in dietary_prefs)]

    if not filtered_meals:
        return {"message": "No meals match the given dietary preferences"}

    def select_meals_for_day(available_meals):
        if len(available_meals) < 3:
            return {"message": "Not enough meals to create a 3-meal plan for one day."}

        selected_meals = random.sample(available_meals, 3)
        return {
            "breakfast": selected_meals[0],
            "lunch": selected_meals[1],
            "dinner": selected_meals[2]
        }

    meal_plan = []
    start_date = datetime.now()

    for day in range(14):
        # Calculate the date for the current day in ISO 8601 format (including timezone info)
        current_date = (start_date + timedelta(days=day)).isoformat()

        day_meals = select_meals_for_day(filtered_meals)

        meal_plan.append({
            "date": current_date,
            # "meals": {
                "breakfast": day_meals["breakfast"]['id'],
                #   {
                #     "meal_id": day_meals["breakfast"]['id'],
                #     "title": day_meals["breakfast"]['title'],
                #     "ingredients": day_meals["breakfast"]['ingredients'],
                #     "instructions": day_meals["breakfast"]['instructions'],
                #     "duration": day_meals["breakfast"]['duration'],
                #     "calories": day_meals["breakfast"]['calories'],
                #     "category": day_meals["breakfast"]['category']['name']
                # },
                "lunch": day_meals["lunch"]['id'],
                #   {
                #     "meal_id": day_meals["lunch"]['id'],
                #     "title": day_meals["lunch"]['title'],
                #     "ingredients": day_meals["lunch"]['ingredients'],
                #     "instructions": day_meals["lunch"]['instructions'],
                #     "duration": day_meals["lunch"]['duration'],
                #     "calories": day_meals["lunch"]['calories'],
                #     "category": day_meals["lunch"]['category']['name']
                # },
                "dinner": day_meals["dinner"]['id'],
                # {
                #     "meal_id": day_meals["dinner"]['id'],
                #     "title": day_meals["dinner"]['title'],
                #     "ingredients": day_meals["dinner"]['ingredients'],
                #     "instructions": day_meals["dinner"]['instructions'],
                #     "duration": day_meals["dinner"]['duration'],
                #     "calories": day_meals["dinner"]['calories'],
                #     "category": day_meals["dinner"]['category']['name']
                # }
            # }
        })

    return {
        "message": "14-day meal plan based on your dietary preferences",
        "meal_plan": meal_plan,
        "title": user_input.get("goal", "No goal provided")
    }


# Run the app
if __name__ == "__main__":
    nest_asyncio.apply()  # Apply nest_asyncio to patch the event loop
    uvicorn.run(app, host="0.0.0.0", port=8000)
